# Wrentham Band WonderCMS Theme

A faithful recreation of the traditional Wrentham Band website for WonderCMS, featuring the band's distinctive green (#33CC33) color scheme and classic layout.

## Features

- **Faithful recreation** - Matches original Wrentham Band design
- **Traditional layout** - Cream top bar, green banner section, black navigation
- **940px centered design** - Classic fixed-width layout
- **Two-column content** - Main content left, sidebar right
- **Simple, clean HTML/CSS** - No JavaScript frameworks needed
- **Mobile responsive** - Adapts gracefully to smaller screens

## Installation

1. Copy the `wrentham-theme` folder to your WonderCMS `themes` directory
2. Log into your WonderCMS admin panel
3. Go to Settings → General
4. Select "wrentham-band" from the theme dropdown
5. Save changes

## Theme Structure

```
wrentham-theme/
├── theme.php              # Main template file
├── css/
│   └── style.css          # Theme styles
├── wcms-modules.json      # Theme metadata
└── README.md             # This file
```

## Editable Areas

The theme provides these editable areas:

### Main Content Area
- `<?= $Wcms->page('content') ?>` - Main page content (changes per page) - appears in left column

### Sidebar
- `<?= $Wcms->block('sidebar') ?>` - Right sidebar content (static across all pages)

## Layout Structure

The theme recreates the original Wrentham Band layout:

1. **Top Bar** - 25px cream/yellow strip with #FFFFCC border
2. **Banner Section** - Green background (#33CC33) containing banner image
   - Banner image should be named `Wrentham-Banner-8.jpg` and placed in theme folder
   - Image is 940px wide x 120px high
3. **Navigation** - Black bar with white text, auto-sizing height
4. **Content Area** - 940px centered container with two columns:
   - Left column: Main content (640px flexible width)
   - Right column: Sidebar (280px fixed width)
5. **Footer** - 140px high gray bar (#C0C0C0) with:
   - Three navigation links: Home Page, Contact us, Engagements
   - Copyright/footer text below links

## Customization Tips

### Colors

The theme uses the original Wrentham Band colors:
- **Primary Green**: `#33CC33` (banner background, navigation hover)
- **Cream/Yellow Border**: `#FFFFCC` (top bar and banner borders)
- **Black**: `#000` (navigation background)
- **Silver Gray**: `#C0C0C0` (footer background)
- **Standard link blue**: `#0000EE` (links)
- **Standard visited purple**: `#551A8B` (visited links)

To change the green color, edit `css/style.css`:

```css
/* Find and replace #33CC33 */
background-color: #33CC33;  /* Banner background */
```

### Banner Image

Your banner image should be:
- **Filename**: `Wrentham-Banner-8.jpg`
- **Location**: Theme root folder
- **Dimensions**: 940px wide x 120px high (approximately)
- **Format**: JPG recommended

To use a different image, edit `theme.php` line with:
```php
<img src="<?= $Wcms->asset('your-banner-image.jpg') ?>" ...>
```

## Content Migration from Old Site

### Recommended WonderCMS Pages

Create these pages to match the old Wrentham Band structure:

1. **Home** (default page)
   - Latest news
   - Recent photos
   - Welcome message

2. **About the Band**
   - Band history
   - Achievements
   - Current objectives

3. **Band Members**
   - Current membership
   - Musical director info
   - Player profiles

4. **Engagements**
   - Upcoming events
   - Past performances
   - Booking information

5. **Photo Gallery**
   - Performance photos
   - Historical images
   - Event coverage

6. **Contact Us**
   - Contact form
   - Email addresses
   - Rehearsal location

7. **Support Us**
   - Easyfundraising info
   - Donation information
   - Sponsorship opportunities

### Sidebar Content Suggestions

Use the `sidebar` block for:
- Booking contact information
- Easyfundraising banner/button
- Player vacancies notice
- Rehearsal times and location
- Social media links (Facebook)
- Sites of interest links
- Latest CD information

### Footer Info Section

Use the `footer-info` block for:
- Additional support appeals
- Important notices
- Special announcements
- Event highlights

## Sample Content

### Sidebar Example

```html
<h4>Bookings and Membership Enquiries</h4>
<p><a href="mailto:bookings@wrenthamband.org"><strong>bookings@wrenthamband.org</strong></a></p>

<h4>Support Us</h4>
<p>Please support us when you shop online by signing up to easyfundraising.</p>
<p><a href="http://www.easyfundraising.org.uk/causes/wrenthamband" target="_blank">
<img src="easyfundbanner.png" alt="Easyfundraising" width="218" height="40"></a></p>

<h4>Current Player Vacancies</h4>
<p>Players of all abilities welcome. We rehearse Mondays at 7:30pm, 
<a href="http://www.wrentham.org.uk/page18a.html">Wrentham Village Hall</a>, 
Wrentham, NR34 7HJ</p>

<h4>Sites of Interest</h4>
<ul>
<li><a href="http://www.4barsrest.com/" target="_blank">4barsrest</a></li>
<li><a href="http://www.bandsman.co.uk/" target="_blank">The Brass Band Portal</a></li>
</ul>
```

### Footer Info Example

```html
<h3>Support Wrentham Band</h3>
<p>Making a donation through easyfundraising is quick, simple and 100% secure. 
Unlike other sites, they don't take a commission on donations.</p>
<p><a href="https://www.easyfundraising.org.uk/causes/wrenthamband/donate/" target="_blank">
Make a Donation</a></p>
```

## Technical Notes

- Requires WonderCMS 3.x or higher
- Pure HTML/CSS - no external frameworks
- No JavaScript dependencies (except WonderCMS admin JS)
- Mobile-first responsive design with breakpoints at 960px and 640px
- 940px fixed-width layout on desktop, fluid on mobile

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- IE11+ (limited support)

## License

Free to use and modify for Wrentham Band purposes.

## Credits

Theme created for Wrentham Band's WonderCMS migration project.
Based on the original Wrentham Band website design (established 1919).
